/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*prgm to check no. is divisible by 5 and 11*/

#include <stdio.h>

int main()
{
  int a;
  printf("enter the value of a");
  scanf("%d",&a);
  if(a%5==0&&a%11==0)
  printf("no. is divisible by 5 and 11");
 
 else
 printf("no. is not divisible by 5 and 11");
  
    return 0;
}

